<footer>
    <div class="width-control nav">
        <div class="nav-logo">
            <!-- <span class="material-icons-sharp">
                pregnant_woman
            </span> -->
            <div class="logo-img">
                <img src="img_resource/logo3.jpg" alt="">
            </div>
            <h3>NHMH.</h3>
        </div>
        <div>
            <h4>NHMH. &copy; Copyright 2022.</h4>
        </div>
    </div>
</footer>